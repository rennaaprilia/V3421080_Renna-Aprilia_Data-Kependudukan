<?php
class Penduduk
{
    private $nik;
    private $nama;
    private $gender;
    private $alamat;
    private $status;
    private $pekerjaan;
    private $wargaNegara;
    private $tempatLahir;
    private $tanggalLahir;
    private $golDarah;

    function __construct($nik, $nama, $gender, $alamat, $status, $pekerjaan, $wargaNegara, $tempatLahir, $tanggalLahir, $golDarah)
    {
        $this->nik = $nik;
        $this->nama = $nama;
        $this->gender = $gender;
        $this->alamat = $alamat;
        $this->status = $status;
        $this->pekerjaan = $pekerjaan;
        $this->wargaNegara = $wargaNegara;
        $this->tempatLahir = $tempatLahir;
        $this->tanggalLahir = $tanggalLahir;
        $this->golDarah = $golDarah;
    }

    // post data
    function tambahData($koneksi)
    {
        $tambahData = "INSERT INTO data_penduduk VALUES ('$this->nik','$this->nama','$this->gender','$this->alamat','$this->status','$this->pekerjaan','$this->wargaNegara','$this->tempatLahir','$this->tanggalLahir','$this->golDarah')";
        $prosesTambah = mysqli_query($koneksi, $tambahData);
    }

    function updateData($koneksi)
    {
        $update = "UPDATE `data_penduduk` SET `NIK` = '$this->nik', `nama` = '$this->nama', `gender` = '$this->gender', `alamat` = '$this->alamat', `status` = '$this->status', `pekerjaan` = '$this->pekerjaan', `warga_negara` = '$this->wargaNegara', `tempat_lahir` = '$this->tempatLahir', `tanggal_lahir` = '$this->tanggalLahir', `gol_darah` = '$this->golDarah' WHERE `data_penduduk`.`NIK` = '$this->nik'";
        $prosesUpdate = mysqli_query($koneksi, $update);
    }

    // ambil data 
    function ambilData($koneksi)
    {
        $dataPenduduk = "SELECT * FROM data_penduduk";
        $prosesAmbilData = mysqli_query($koneksi, $dataPenduduk);
        return $prosesAmbilData;
    }

    // ambil data 
    function ambilDataByNIK($koneksi, $nik)
    {
        $dataPenduduk = "SELECT * FROM data_penduduk WHERE `NIK`=$nik";
        $prosesAmbilData = mysqli_query($koneksi, $dataPenduduk);
        return $prosesAmbilData;
    }

    // hapus data
    function hapusData($koneksi, $nik)
    {
        $hapusData = "DELETE FROM data_penduduk WHERE `NIK`=$nik";
        $prosesHapus = mysqli_query($koneksi, $hapusData);
    }
}